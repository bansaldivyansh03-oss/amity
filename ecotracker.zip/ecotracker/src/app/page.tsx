"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { useAppStore } from "@/lib/store";

export default function SplashPage() {
  const router = useRouter();
  const hydrated = useAppStore((s) => s.hydrated);
  const profile = useAppStore((s) => s.profile);
  const [minTimeElapsed, setMinTimeElapsed] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setMinTimeElapsed(true), 1900);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!hydrated || !minTimeElapsed) return;
    if (!profile.onboarded) router.replace("/onboarding");
    else if (!profile.authMethod) router.replace("/login");
    else router.replace("/dashboard");
  }, [hydrated, minTimeElapsed, profile, router]);

  return (
    <div className="min-h-dvh flex flex-col items-center justify-center bg-canopy text-mist gap-6">
      <motion.div
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      >
        <EarthMark />
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="text-center"
      >
        <h1 className="font-display text-3xl font-semibold tracking-tight">EcoTracker</h1>
        <p className="text-sm text-lichen/80 mt-1">Grow a lighter footprint</p>
      </motion.div>
    </div>
  );
}

function EarthMark() {
  return (
    <div className="relative h-28 w-28">
      <motion.div
        className="absolute inset-0 rounded-full"
        style={{
          background:
            "radial-gradient(circle at 32% 28%, #6E9A7C 0%, #4C7A5B 42%, #1E3D30 100%)",
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
      />
      <svg viewBox="0 0 100 100" className="absolute inset-0">
        <motion.path
          d="M20 35 Q35 25 50 32 T78 30"
          stroke="#A8C686"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.85 }}
          transition={{ duration: 1.4, delay: 0.3 }}
        />
        <motion.path
          d="M15 60 Q34 68 52 60 T85 65"
          stroke="#A8C686"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.7 }}
          transition={{ duration: 1.4, delay: 0.6 }}
        />
      </svg>
      <motion.div
        className="absolute -inset-2 rounded-full border border-lichen/30"
        animate={{ scale: [1, 1.15, 1], opacity: [0.6, 0, 0.6] }}
        transition={{ duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
}
