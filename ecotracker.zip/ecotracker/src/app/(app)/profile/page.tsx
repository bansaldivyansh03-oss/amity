"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Bell,
  Globe,
  Ruler,
  Download,
  LogOut,
  Trash2,
  Trophy,
  ChevronRight,
  MessageCircleHeart,
} from "lucide-react";
import { useAppStore, currentLevel } from "@/lib/store";
import { ACHIEVEMENT_DEFS } from "@/lib/achievements";
import PageHeader from "@/components/PageHeader";
import Link from "next/link";

const AVATARS = ["🌱", "🌍", "🦉", "🦊", "🐼", "🐢", "🌳", "🍃"];

export default function ProfilePage() {
  const router = useRouter();
  const profile = useAppStore((s) => s.profile);
  const updateProfile = useAppStore((s) => s.updateProfile);
  const gamification = useAppStore((s) => s.gamification);
  const activities = useAppStore((s) => s.activities);
  const logout = useAppStore((s) => s.logout);
  const resetAll = useAppStore((s) => s.resetAll);

  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState(profile.name);
  const [notifications, setNotifications] = useState({
    reminders: true,
    achievements: true,
    challenges: true,
    weather: false,
    weekly: true,
  });
  const [showAvatars, setShowAvatars] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const level = currentLevel(gamification.xp);
  const unlockedAchievements = gamification.achievements.filter((a) => a.unlocked);

  function exportJson() {
    const payload = { profile, activities, gamification };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "ecotracker-backup.json";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="pb-4">
      <PageHeader title="Profile" />

      <div className="px-5">
        {/* Avatar + name */}
        <div className="rounded-3xl bg-surface border border-border-soft p-5 flex items-center gap-4">
          <button
            onClick={() => setShowAvatars((v) => !v)}
            className="h-16 w-16 rounded-3xl bg-moss/15 flex items-center justify-center text-3xl active:scale-95 transition-transform"
          >
            {profile.avatar}
          </button>
          <div className="flex-1">
            {editingName ? (
              <input
                autoFocus
                value={nameDraft}
                onChange={(e) => setNameDraft(e.target.value)}
                onBlur={() => {
                  updateProfile({ name: nameDraft || profile.name });
                  setEditingName(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                }}
                className="font-display text-lg font-semibold bg-transparent border-b border-moss outline-none w-full"
              />
            ) : (
              <button onClick={() => setEditingName(true)} className="font-display text-lg font-semibold text-left">
                {profile.name || "Guest"}
              </button>
            )}
            <p className="text-xs text-foreground-soft mt-0.5">{profile.email || "Local guest account"}</p>
            <p className="text-xs text-moss font-medium mt-1">{level.name} · {gamification.xp} XP</p>
          </div>
        </div>

        {showAvatars && (
          <div className="mt-2 rounded-2xl bg-surface border border-border-soft p-3 flex flex-wrap gap-2 rise-fade">
            {AVATARS.map((a) => (
              <button
                key={a}
                onClick={() => {
                  updateProfile({ avatar: a });
                  setShowAvatars(false);
                }}
                className={`h-11 w-11 rounded-2xl flex items-center justify-center text-xl border ${
                  profile.avatar === a ? "border-moss bg-moss/10" : "border-border-soft"
                }`}
              >
                {a}
              </button>
            ))}
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          <MiniStat label="Activities" value={`${activities.length}`} />
          <MiniStat label="Green Coins" value={`${gamification.greenCoins}`} />
          <MiniStat label="Streak" value={`${gamification.streak}d`} />
        </div>

        {/* Achievements */}
        <SectionCard title="Achievements" icon={Trophy}>
          <div className="grid grid-cols-4 gap-2.5">
            {ACHIEVEMENT_DEFS.map((def) => {
              const unlocked = unlockedAchievements.some((a) => a.id === def.id);
              return (
                <div key={def.id} className="flex flex-col items-center gap-1" title={def.description}>
                  <div
                    className={`h-12 w-12 rounded-2xl flex items-center justify-center ${
                      unlocked ? "bg-moss/15" : "bg-border-soft/40 grayscale opacity-50"
                    }`}
                  >
                    <Trophy size={18} className={unlocked ? "text-moss" : "text-foreground-soft"} />
                  </div>
                  <p className="text-[9px] text-center text-foreground-soft leading-tight">{def.title}</p>
                </div>
              );
            })}
          </div>
        </SectionCard>

        {/* Eco Assistant link */}
        <Link
          href="/assistant"
          className="mt-4 flex items-center justify-between rounded-2xl bg-surface border border-border-soft p-4"
        >
          <span className="flex items-center gap-3 text-sm font-medium">
            <MessageCircleHeart size={18} className="text-moss" /> Ask the Eco Assistant
          </span>
          <ChevronRight size={16} className="text-foreground-soft" />
        </Link>

        {/* Notifications */}
        <SectionCard title="Notifications" icon={Bell}>
          <div className="flex flex-col gap-3">
            {(
              [
                ["reminders", "Daily reminders"],
                ["achievements", "Achievement alerts"],
                ["challenges", "Challenge nudges"],
                ["weather", "Weather & AQI alerts"],
                ["weekly", "Weekly summary"],
              ] as const
            ).map(([key, label]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-sm">{label}</span>
                <Switch
                  checked={notifications[key]}
                  onChange={(v) => setNotifications((n) => ({ ...n, [key]: v }))}
                />
              </div>
            ))}
          </div>
        </SectionCard>

        {/* Preferences */}
        <SectionCard title="Preferences" icon={Ruler}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm">Units</span>
            <select
              value={profile.units}
              onChange={(e) => updateProfile({ units: e.target.value as "metric" | "imperial" })}
              className="rounded-lg bg-background border border-border-soft px-2 py-1 text-sm"
            >
              <option value="metric">Metric (kg, km)</option>
              <option value="imperial">Imperial (lb, mi)</option>
            </select>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm flex items-center gap-1.5"><Globe size={14} /> Language</span>
            <select
              value={profile.language}
              onChange={(e) => updateProfile({ language: e.target.value })}
              className="rounded-lg bg-background border border-border-soft px-2 py-1 text-sm"
            >
              <option value="en">English</option>
              <option value="hi">हिंदी</option>
              <option value="es">Español</option>
            </select>
          </div>
        </SectionCard>

        {/* Data */}
        <SectionCard title="Data & privacy" icon={Download}>
          <button
            onClick={exportJson}
            className="w-full rounded-xl bg-moss/10 text-moss text-sm font-medium py-3 border border-moss/30 mb-2"
          >
            Export all data (JSON)
          </button>
          <p className="text-[11px] text-foreground-soft">
            Data is stored locally on this device. Exporting creates a backup file you can keep.
          </p>
        </SectionCard>

        <div className="flex flex-col gap-2 mt-4 mb-6">
          <button
            onClick={() => {
              logout();
              router.replace("/login");
            }}
            className="flex items-center justify-center gap-2 rounded-2xl border border-border-soft py-3 text-sm font-medium text-foreground-soft"
          >
            <LogOut size={15} /> Sign out
          </button>
          {!confirmReset ? (
            <button
              onClick={() => setConfirmReset(true)}
              className="flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-medium text-ember"
            >
              <Trash2 size={15} /> Reset all data
            </button>
          ) : (
            <div className="rounded-2xl border border-ember/40 p-3 text-center">
              <p className="text-xs text-foreground-soft mb-2">
                This clears all activities, achievements, and progress on this device. This can&apos;t be undone.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => setConfirmReset(false)}
                  className="flex-1 rounded-xl border border-border-soft py-2 text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    resetAll();
                    router.replace("/onboarding");
                  }}
                  className="flex-1 rounded-xl bg-ember text-mist py-2 text-sm font-medium"
                >
                  Confirm reset
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-surface border border-border-soft p-3 text-center">
      <p className="font-mono text-lg font-semibold">{value}</p>
      <p className="text-[10px] text-foreground-soft mt-0.5">{label}</p>
    </div>
  );
}

function SectionCard({
  title,
  icon: Icon,
  children,
}: {
  title: string;
  icon: typeof Bell;
  children: React.ReactNode;
}) {
  return (
    <div className="mt-4 rounded-3xl bg-surface border border-border-soft p-4">
      <p className="text-sm font-medium mb-3 flex items-center gap-2">
        <Icon size={15} className="text-moss" /> {title}
      </p>
      {children}
    </div>
  );
}

function Switch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`h-6 w-11 rounded-full flex items-center px-0.5 transition-colors ${checked ? "bg-moss justify-end" : "bg-border-soft justify-start"}`}
    >
      <div className="h-5 w-5 rounded-full bg-white shadow" />
    </button>
  );
}
