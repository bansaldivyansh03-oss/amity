"use client";

import { useMemo, useState } from "react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import { TrendingUp, Sparkles } from "lucide-react";
import { useAppStore } from "@/lib/store";
import {
  weeklySeries,
  monthlySeries,
  categoryBreakdown,
  forecast,
  last7Days,
  last30Days,
  averageDailyKg,
} from "@/lib/analytics";
import PageHeader from "@/components/PageHeader";

export default function AnalyticsPage() {
  const activities = useAppStore((s) => s.activities);
  const [range, setRange] = useState<"week" | "month">("week");

  const week = useMemo(() => weeklySeries(activities), [activities]);
  const month = useMemo(() => monthlySeries(activities), [activities]);
  const breakdown = useMemo(
    () => categoryBreakdown(activities, range === "week" ? last7Days()[0] : last30Days()[0]),
    [activities, range]
  );
  const fc = useMemo(() => forecast(activities), [activities]);
  const weekAvg = averageDailyKg(activities, last7Days());
  const prevWeekDays = useMemo(() => {
    const days: string[] = [];
    for (let i = 13; i >= 7; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      days.push(d.toISOString().slice(0, 10));
    }
    return days;
  }, []);
  const prevWeekAvg = averageDailyKg(activities, prevWeekDays);
  const trendPct = prevWeekAvg > 0 ? Math.round(((weekAvg - prevWeekAvg) / prevWeekAvg) * 100) : 0;

  const lifetimeTotal = activities.reduce((s, a) => s + a.co2kg, 0);
  const personalRecordDay = useMemo(() => {
    const byDay = new Map<string, number>();
    for (const a of activities) {
      const d = a.createdAt.slice(0, 10);
      byDay.set(d, (byDay.get(d) ?? 0) + a.co2kg);
    }
    let best: [string, number] | null = null;
    for (const entry of byDay.entries()) {
      if (!best || entry[1] < best[1]) best = entry;
    }
    return best;
  }, [activities]);

  const series = range === "week" ? week : month;

  return (
    <div className="pb-4">
      <PageHeader title="Analytics" subtitle="Trends, forecasts, and insights" />

      <div className="px-5">
        <div className="flex gap-2 mb-4">
          {(["week", "month"] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`px-3.5 py-1.5 rounded-full text-sm border ${
                range === r ? "bg-moss text-mist border-moss" : "bg-surface border-border-soft text-foreground-soft"
              }`}
            >
              {r === "week" ? "This week" : "Last 30 days"}
            </button>
          ))}
        </div>

        {/* Trend summary */}
        <div className="rounded-3xl bg-surface border border-border-soft p-4 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-foreground-soft">Daily average, this week</p>
              <p className="font-mono text-2xl font-semibold mt-0.5">{weekAvg.toFixed(1)} kg</p>
            </div>
            <div className={`flex items-center gap-1 text-sm font-medium ${trendPct <= 0 ? "text-moss" : "text-ember"}`}>
              <TrendingUp size={16} className={trendPct <= 0 ? "rotate-180" : ""} />
              {trendPct === 0 ? "—" : `${trendPct > 0 ? "+" : ""}${trendPct}%`}
            </div>
          </div>
          <p className="text-[11px] text-foreground-soft mt-1">vs. previous week</p>
        </div>

        {/* Line chart */}
        <div className="rounded-3xl bg-surface border border-border-soft p-4 mb-4">
          <p className="text-sm font-medium mb-2">CO₂ over time</p>
          <div className="h-40 -ml-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-soft)" vertical={false} />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: "var(--foreground-soft)" }} interval={range === "month" ? 4 : 0} />
                <YAxis hide />
                <Tooltip
                  contentStyle={{ background: "var(--surface)", border: "1px solid var(--border-soft)", borderRadius: 12, fontSize: 12 }}
                  formatter={(v) => [`${v} kg`, "CO₂"] as [string, string]}
                />
                <Line type="monotone" dataKey="co2" stroke="var(--moss)" strokeWidth={2.2} dot={range === "week"} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bar chart */}
        <div className="rounded-3xl bg-surface border border-border-soft p-4 mb-4">
          <p className="text-sm font-medium mb-2">Daily breakdown</p>
          <div className="h-40 -ml-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={series}>
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: "var(--foreground-soft)" }} interval={range === "month" ? 4 : 0} />
                <YAxis hide />
                <Tooltip
                  contentStyle={{ background: "var(--surface)", border: "1px solid var(--border-soft)", borderRadius: 12, fontSize: 12 }}
                  formatter={(v) => [`${v} kg`, "CO₂"] as [string, string]}
                />
                <Bar dataKey="co2" fill="var(--sky)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie chart - category breakdown */}
        <div className="rounded-3xl bg-surface border border-border-soft p-4 mb-4">
          <p className="text-sm font-medium mb-2">Emission breakdown by category</p>
          {breakdown.length === 0 ? (
            <p className="text-sm text-foreground-soft text-center py-8">No data for this range yet.</p>
          ) : (
            <div className="flex items-center gap-4">
              <div className="h-36 w-36 shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={breakdown} dataKey="value" nameKey="name" innerRadius={35} outerRadius={60} paddingAngle={2}>
                      {breakdown.map((entry, i) => (
                        <Cell key={i} fill={entry.color} stroke="none" />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ background: "var(--surface)", border: "1px solid var(--border-soft)", borderRadius: 12, fontSize: 12 }}
                      formatter={(v) => [`${v} kg`, "CO₂"] as [string, string]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 flex flex-col gap-1.5">
                {breakdown.map((b) => (
                  <div key={b.category} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full" style={{ backgroundColor: b.color }} />
                      {b.name}
                    </span>
                    <span className="font-mono text-foreground-soft">{b.value}kg</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Records */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="rounded-2xl bg-surface border border-border-soft p-3.5">
            <p className="text-[11px] text-foreground-soft">Lifetime total</p>
            <p className="font-mono text-lg font-semibold mt-0.5">{lifetimeTotal.toFixed(1)} kg</p>
          </div>
          <div className="rounded-2xl bg-surface border border-border-soft p-3.5">
            <p className="text-[11px] text-foreground-soft">Best day (lowest CO₂)</p>
            <p className="font-mono text-lg font-semibold mt-0.5">
              {personalRecordDay ? `${personalRecordDay[1].toFixed(1)} kg` : "—"}
            </p>
          </div>
        </div>

        {/* Forecast */}
        <div className="rounded-3xl bg-canopy text-mist p-4 mb-4">
          <p className="text-sm font-medium mb-3">Carbon Prediction Engine</p>
          <div className="flex flex-col gap-2.5">
            {fc.map((f) => (
              <div key={f.label} className="flex items-center justify-between text-sm">
                <span className="text-mist/70">{f.label}</span>
                <span className="font-mono">
                  {f.projectedKg}kg
                  <span className="text-lichen text-xs ml-2">→ {f.reducedKg}kg with -20%</span>
                </span>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-mist/50 mt-3">
            Based on your trailing 7-day average. The -20% column shows the effect of a modest, sustained reduction.
          </p>
        </div>

        {/* AI Insight */}
        <div className="rounded-3xl border border-dashed border-moss/40 p-4 mb-6 flex gap-3">
          <Sparkles size={18} className="text-moss shrink-0 mt-0.5" />
          <p className="text-sm leading-relaxed">
            {breakdown[0]
              ? `${breakdown[0].name} is driving most of your footprint this ${range === "week" ? "week" : "month"}, at ${breakdown[0].value}kg CO₂. Small, repeated swaps in this category will move your average the fastest.`
              : "Log a few activities across categories and I'll highlight which habit is contributing the most to your footprint."}
          </p>
        </div>
      </div>
    </div>
  );
}
