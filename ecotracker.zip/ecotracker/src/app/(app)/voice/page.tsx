"use client";

import { useEffect, useRef, useState } from "react";
import { Mic, Square, Check } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { useAppStore } from "@/lib/store";
import { parseVoiceTranscript, type VoiceParseResult } from "@/lib/voiceparse";

// Minimal ambient typing for the Web Speech API (not in default TS lib)
interface SpeechRecognitionResultLike {
  isFinal: boolean;
  [index: number]: { transcript: string };
}
interface SpeechRecognitionEventLike extends Event {
  results: ArrayLike<SpeechRecognitionResultLike>;
}
interface SpeechRecognitionLike extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onend: (() => void) | null;
  onerror: ((ev: Event) => void) | null;
}

const EXAMPLES = [
  '"I travelled 15 kilometres by metro today"',
  '"I had a vegan meal"',
  '"I recycled 2 kilograms of plastic"',
  '"I used 3 kWh of electricity"',
];

export default function VoicePage() {
  const addActivity = useAppStore((s) => s.addActivity);
  const [supported, setSupported] = useState(true);
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [result, setResult] = useState<VoiceParseResult | null>(null);
  const [logged, setLogged] = useState(false);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => {
    const w = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- one-time browser capability check on mount
      setSupported(false);
      return;
    }
    const recognition = new Ctor();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = "en-US";
    recognition.onresult = (ev) => {
      let text = "";
      for (let i = 0; i < ev.results.length; i++) text += ev.results[i][0].transcript;
      setTranscript(text);
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognitionRef.current = recognition;
  }, []);

  function start() {
    setResult(null);
    setTranscript("");
    setLogged(false);
    setListening(true);
    recognitionRef.current?.start();
  }
  function stop() {
    recognitionRef.current?.stop();
    setListening(false);
  }

  useEffect(() => {
    if (!listening && transcript) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- derives parsed result once external speech recognition finishes
      setResult(parseVoiceTranscript(transcript));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [listening]);

  function logIt() {
    if (result?.entry) {
      addActivity(result.entry);
      setLogged(true);
      setTimeout(() => setLogged(false), 1800);
    }
  }

  return (
    <div className="pb-6">
      <PageHeader title="Voice Logging" subtitle="Speak naturally, I'll structure it" back />

      <div className="px-5 flex flex-col items-center">
        {!supported ? (
          <div className="rounded-2xl bg-surface border border-border-soft p-4 text-sm text-foreground-soft text-center">
            Voice logging needs browser speech recognition (works in Chrome/Edge on desktop and Android).
            Your current browser doesn&apos;t support it — try Log Activity instead.
          </div>
        ) : (
          <>
            <button
              onClick={listening ? stop : start}
              className={`h-24 w-24 rounded-full flex items-center justify-center transition-colors ${
                listening ? "bg-ember text-mist pulse-soft" : "bg-moss text-mist"
              }`}
              aria-label={listening ? "Stop listening" : "Start listening"}
            >
              {listening ? <Square size={28} /> : <Mic size={30} />}
            </button>
            <p className="text-sm text-foreground-soft mt-4">
              {listening ? "Listening…" : "Tap to speak"}
            </p>

            {transcript && (
              <div className="w-full rounded-2xl bg-surface border border-border-soft p-4 mt-6">
                <p className="text-[11px] text-foreground-soft mb-1">You said</p>
                <p className="text-sm">&ldquo;{transcript}&rdquo;</p>
              </div>
            )}

            {result && (
              <div className="w-full rounded-3xl bg-canopy text-mist p-4 mt-4 rise-fade">
                <p className="text-sm">{result.interpretation}</p>
                {result.entry && (
                  <>
                    <p className="font-mono text-xl font-semibold mt-2">{result.entry.co2kg} kg CO₂</p>
                    <button
                      onClick={logIt}
                      className="w-full mt-3 rounded-2xl bg-lichen text-canopy font-semibold py-3 flex items-center justify-center gap-2"
                    >
                      <Check size={16} /> Log this activity
                    </button>
                    {logged && <p className="text-center text-xs text-lichen mt-2">Logged ✓</p>}
                  </>
                )}
              </div>
            )}

            <div className="w-full mt-8">
              <p className="text-xs text-foreground-soft mb-2">Try saying things like:</p>
              <div className="flex flex-col gap-1.5">
                {EXAMPLES.map((e) => (
                  <p key={e} className="text-xs text-foreground-soft/80 italic">
                    {e}
                  </p>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
