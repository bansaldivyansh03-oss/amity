"use client";

import { useEffect, useRef, useState } from "react";
import { Send, Sparkles } from "lucide-react";
import { useAppStore } from "@/lib/store";
import { assistantReply } from "@/lib/assistant";
import PageHeader from "@/components/PageHeader";

interface Message {
  role: "user" | "assistant";
  text: string;
}

const SUGGESTIONS = [
  "What's my biggest emission source?",
  "How am I doing this week?",
  "How can I reduce my footprint?",
  "Set a goal for me",
];

export default function AssistantPage() {
  const profile = useAppStore((s) => s.profile);
  const activities = useAppStore((s) => s.activities);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      text: `Hi ${profile.name || "there"}! I'm your Eco Assistant. Ask me anything about your footprint, or tap a suggestion below.`,
    },
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  function send(text: string) {
    if (!text.trim()) return;
    const reply = assistantReply(text, { activities, name: profile.name });
    setMessages((m) => [...m, { role: "user", text }, { role: "assistant", text: reply }]);
    setInput("");
  }

  return (
    <div className="flex flex-col h-dvh">
      <PageHeader title="Eco Assistant" subtitle="Ask about your footprint" back />

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-2 flex flex-col gap-3">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                m.role === "user" ? "bg-moss text-mist rounded-br-sm" : "bg-surface border border-border-soft rounded-bl-sm"
              }`}
            >
              {m.role === "assistant" && (
                <Sparkles size={12} className="inline mr-1.5 -mt-0.5 text-moss" />
              )}
              {m.text}
            </div>
          </div>
        ))}
      </div>

      <div className="px-5 pb-2 flex gap-2 overflow-x-auto scrollbar-none">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => send(s)}
            className="whitespace-nowrap text-xs bg-surface border border-border-soft rounded-full px-3 py-1.5 text-foreground-soft"
          >
            {s}
          </button>
        ))}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="px-5 pb-6 pt-2 flex gap-2 border-t border-border-soft"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about your carbon footprint..."
          className="flex-1 rounded-2xl bg-surface border border-border-soft px-4 py-3 outline-none focus:border-moss text-sm"
        />
        <button
          type="submit"
          className="h-11 w-11 rounded-2xl bg-moss text-mist flex items-center justify-center shrink-0"
          aria-label="Send"
        >
          <Send size={16} />
        </button>
      </form>
    </div>
  );
}
