"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Search, Mic, Camera, ScanLine, Trash } from "lucide-react";
import { useAppStore } from "@/lib/store";
import {
  calcTransport,
  calcElectricity,
  calcCooking,
  calcFood,
  calcShopping,
  calcWaste,
  calcWater,
  TRANSPORT_LABELS,
  FOOD_LABELS,
  SHOPPING_LABELS,
  WASTE_LABELS,
} from "@/lib/emissions";
import type {
  ActivityCategory,
  ActivityEntry,
  CookingFuel,
  FoodType,
  ShoppingType,
  TransportMode,
  WasteType,
} from "@/lib/types";
import { CATEGORY_ICON, CATEGORY_LABEL } from "@/components/categoryMeta";

const CATEGORIES: ActivityCategory[] = [
  "transport",
  "electricity",
  "cooking",
  "food",
  "shopping",
  "waste",
  "water",
];

export default function LogActivityPage() {
  const [tab, setTab] = useState<ActivityCategory>("transport");
  const addActivity = useAppStore((s) => s.addActivity);
  const activities = useAppStore((s) => s.activities);
  const deleteActivity = useAppStore((s) => s.deleteActivity);

  const [preview, setPreview] = useState<Omit<ActivityEntry, "id" | "createdAt"> | null>(null);
  const [justLogged, setJustLogged] = useState(false);

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<ActivityCategory | "all">("all");

  const filteredHistory = useMemo(() => {
    return activities.filter((a) => {
      if (filter !== "all" && a.category !== filter) return false;
      if (search && !a.label.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [activities, search, filter]);

  function logPreview() {
    if (!preview) return;
    addActivity(preview);
    setPreview(null);
    setJustLogged(true);
    setTimeout(() => setJustLogged(false), 1800);
  }

  function exportCsv() {
    const header = "Date,Category,Label,Detail,CO2 (kg)\n";
    const rows = activities
      .map((a) => `${a.createdAt},${a.category},"${a.label}","${a.detail}",${a.co2kg}`)
      .join("\n");
    const blob = new Blob([header + rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "ecotracker-activity-history.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="pt-6">
      <div className="px-5 flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold tracking-tight">Log Activity</h1>
        <div className="flex gap-2">
          <Link
            href="/voice"
            className="h-9 w-9 rounded-full bg-surface border border-border-soft flex items-center justify-center"
            aria-label="Voice logging"
          >
            <Mic size={16} />
          </Link>
          <Link
            href="/scan"
            className="h-9 w-9 rounded-full bg-surface border border-border-soft flex items-center justify-center"
            aria-label="AI Eco Scan"
          >
            <Camera size={16} />
          </Link>
        </div>
      </div>

      {/* Category tabs */}
      <div className="mt-4 px-5 flex gap-2 overflow-x-auto scrollbar-none pb-1">
        {CATEGORIES.map((c) => {
          const Icon = CATEGORY_ICON[c];
          const active = tab === c;
          return (
            <button
              key={c}
              onClick={() => {
                setTab(c);
                setPreview(null);
              }}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-sm whitespace-nowrap border transition-colors ${
                active
                  ? "bg-moss text-mist border-moss"
                  : "bg-surface border-border-soft text-foreground-soft"
              }`}
            >
              <Icon size={14} />
              {CATEGORY_LABEL[c]}
            </button>
          );
        })}
      </div>

      <div className="px-5 mt-4">
        {tab === "transport" && <TransportForm onPreview={setPreview} />}
        {tab === "electricity" && <ElectricityForm onPreview={setPreview} />}
        {tab === "cooking" && <CookingForm onPreview={setPreview} />}
        {tab === "food" && <FoodForm onPreview={setPreview} />}
        {tab === "shopping" && <ShoppingForm onPreview={setPreview} />}
        {tab === "waste" && <WasteForm onPreview={setPreview} />}
        {tab === "water" && <WaterForm onPreview={setPreview} />}
      </div>

      {preview && (
        <div className="px-5 mt-4">
          <div className="rounded-3xl bg-canopy text-mist p-4 rise-fade">
            <p className="text-[11px] uppercase tracking-wide text-lichen">Estimated impact</p>
            <p className="font-mono text-2xl font-semibold mt-1">{preview.co2kg} kg CO₂</p>
            <p className="text-xs text-mist/70 mt-1">{preview.formula}</p>
            <p className="text-xs text-lichen mt-2">
              ≈ {preview.treeDaysEquivalent} tree-days to absorb this
            </p>
            {preview.alternatives.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {preview.alternatives.map((alt, i) => (
                  <span key={i} className="text-[11px] bg-lichen/15 text-lichen rounded-full px-2.5 py-1">
                    {alt}
                  </span>
                ))}
              </div>
            )}
            <button
              onClick={logPreview}
              className="w-full mt-4 rounded-2xl bg-lichen text-canopy font-semibold py-3 active:scale-[0.98] transition-transform"
            >
              Log this activity
            </button>
          </div>
        </div>
      )}

      {justLogged && (
        <div className="px-5 mt-3">
          <p className="text-sm text-moss font-medium text-center">Activity logged ✓</p>
        </div>
      )}

      {/* History */}
      <div className="px-5 mt-8">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-lg font-semibold">History</h2>
          <button onClick={exportCsv} className="text-xs text-moss">
            Export CSV
          </button>
        </div>
        <div className="flex gap-2 mb-3">
          <div className="flex-1 flex items-center gap-2 rounded-xl bg-surface border border-border-soft px-3 py-2">
            <Search size={14} className="text-foreground-soft" />
            <input
              placeholder="Search activities"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-transparent outline-none text-sm flex-1"
            />
          </div>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as ActivityCategory | "all")}
            className="rounded-xl bg-surface border border-border-soft px-2 text-sm"
          >
            <option value="all">All</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {CATEGORY_LABEL[c]}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-2 pb-4">
          {filteredHistory.length === 0 && (
            <p className="text-sm text-foreground-soft text-center py-8">
              Nothing logged yet — your entries will appear here.
            </p>
          )}
          {filteredHistory.slice(0, 40).map((a) => {
            const Icon = CATEGORY_ICON[a.category];
            return (
              <div
                key={a.id}
                className="flex items-center gap-3 rounded-2xl bg-surface border border-border-soft p-3"
              >
                <div
                  className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0"
                  style={{ backgroundColor: "var(--moss)22", color: "var(--moss)" }}
                >
                  <Icon size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{a.label}</p>
                  <p className="text-[11px] text-foreground-soft">
                    {new Date(a.createdAt).toLocaleString(undefined, {
                      month: "short",
                      day: "numeric",
                      hour: "numeric",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
                <p className="font-mono text-sm shrink-0">{a.co2kg}kg</p>
                <button
                  onClick={() => deleteActivity(a.id)}
                  aria-label="Delete activity"
                  className="text-foreground-soft/50 shrink-0"
                >
                  <Trash size={14} />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ---------- Forms ---------- */

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <label className="text-xs text-foreground-soft mb-1 block">{children}</label>;
}

const inputClass =
  "w-full rounded-xl bg-surface border border-border-soft px-3.5 py-3 outline-none focus:border-moss text-sm";

function TransportForm({ onPreview }: { onPreview: (e: Omit<ActivityEntry, "id" | "createdAt">) => void }) {
  const [mode, setMode] = useState<TransportMode>("car");
  const [km, setKm] = useState(5);
  const [passengers, setPassengers] = useState(1);

  return (
    <div className="flex flex-col gap-3">
      <div>
        <FieldLabel>Mode of transport</FieldLabel>
        <select value={mode} onChange={(e) => setMode(e.target.value as TransportMode)} className={inputClass}>
          {Object.entries(TRANSPORT_LABELS).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
      </div>
      <div>
        <FieldLabel>Distance travelled (km)</FieldLabel>
        <input
          type="number"
          min={0}
          value={km}
          onChange={(e) => setKm(Number(e.target.value))}
          className={inputClass}
        />
      </div>
      <div>
        <FieldLabel>Number of passengers (incl. you)</FieldLabel>
        <input
          type="number"
          min={1}
          value={passengers}
          onChange={(e) => setPassengers(Number(e.target.value))}
          className={inputClass}
        />
      </div>
      <PreviewButton onClick={() => onPreview(calcTransport(mode, km, passengers))} />
    </div>
  );
}

function ElectricityForm({ onPreview }: { onPreview: (e: Omit<ActivityEntry, "id" | "createdAt">) => void }) {
  const [kwh, setKwh] = useState(3);
  const [appliance, setAppliance] = useState("");

  return (
    <div className="flex flex-col gap-3">
      <div>
        <FieldLabel>Electricity consumed (kWh)</FieldLabel>
        <input type="number" min={0} value={kwh} onChange={(e) => setKwh(Number(e.target.value))} className={inputClass} />
      </div>
      <div>
        <FieldLabel>Appliance / source (optional)</FieldLabel>
        <input
          placeholder="e.g. AC, washing machine"
          value={appliance}
          onChange={(e) => setAppliance(e.target.value)}
          className={inputClass}
        />
      </div>
      <PreviewButton onClick={() => onPreview(calcElectricity(kwh, appliance))} />
    </div>
  );
}

function CookingForm({ onPreview }: { onPreview: (e: Omit<ActivityEntry, "id" | "createdAt">) => void }) {
  const [fuel, setFuel] = useState<CookingFuel>("lpg");
  const [hours, setHours] = useState(1);

  return (
    <div className="flex flex-col gap-3">
      <div>
        <FieldLabel>Cooking fuel</FieldLabel>
        <select value={fuel} onChange={(e) => setFuel(e.target.value as CookingFuel)} className={inputClass}>
          <option value="lpg">LPG cylinder</option>
          <option value="piped_gas">Piped natural gas</option>
          <option value="induction">Induction (electric)</option>
          <option value="firewood">Firewood</option>
        </select>
      </div>
      <div>
        <FieldLabel>Duration (hours)</FieldLabel>
        <input type="number" min={0} step={0.5} value={hours} onChange={(e) => setHours(Number(e.target.value))} className={inputClass} />
      </div>
      <PreviewButton onClick={() => onPreview(calcCooking(fuel, hours))} />
    </div>
  );
}

function FoodForm({ onPreview }: { onPreview: (e: Omit<ActivityEntry, "id" | "createdAt">) => void }) {
  const [type, setType] = useState<FoodType>("vegetarian");
  const [servings, setServings] = useState(1);

  return (
    <div className="flex flex-col gap-3">
      <div>
        <FieldLabel>Meal type</FieldLabel>
        <select value={type} onChange={(e) => setType(e.target.value as FoodType)} className={inputClass}>
          {Object.entries(FOOD_LABELS).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
      </div>
      <div>
        <FieldLabel>Meal size (servings)</FieldLabel>
        <input type="number" min={1} value={servings} onChange={(e) => setServings(Number(e.target.value))} className={inputClass} />
      </div>
      <PreviewButton onClick={() => onPreview(calcFood(type, servings))} />
    </div>
  );
}

function ShoppingForm({ onPreview }: { onPreview: (e: Omit<ActivityEntry, "id" | "createdAt">) => void }) {
  const [type, setType] = useState<ShoppingType>("clothing");
  const [quantity, setQuantity] = useState(1);

  return (
    <div className="flex flex-col gap-3">
      <div>
        <FieldLabel>Product category</FieldLabel>
        <select value={type} onChange={(e) => setType(e.target.value as ShoppingType)} className={inputClass}>
          {Object.entries(SHOPPING_LABELS).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
      </div>
      <div>
        <FieldLabel>Quantity</FieldLabel>
        <input type="number" min={1} value={quantity} onChange={(e) => setQuantity(Number(e.target.value))} className={inputClass} />
      </div>
      <PreviewButton onClick={() => onPreview(calcShopping(type, quantity))} />
    </div>
  );
}

function WasteForm({ onPreview }: { onPreview: (e: Omit<ActivityEntry, "id" | "createdAt">) => void }) {
  const [type, setType] = useState<WasteType>("plastic");
  const [kg, setKg] = useState(0.5);

  return (
    <div className="flex flex-col gap-3">
      <div>
        <FieldLabel>Waste type</FieldLabel>
        <select value={type} onChange={(e) => setType(e.target.value as WasteType)} className={inputClass}>
          {Object.entries(WASTE_LABELS).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
      </div>
      <div>
        <FieldLabel>Quantity (kg)</FieldLabel>
        <input type="number" min={0} step={0.1} value={kg} onChange={(e) => setKg(Number(e.target.value))} className={inputClass} />
      </div>
      <PreviewButton onClick={() => onPreview(calcWaste(type, kg))} />
    </div>
  );
}

function WaterForm({ onPreview }: { onPreview: (e: Omit<ActivityEntry, "id" | "createdAt">) => void }) {
  const [litres, setLitres] = useState(20);

  return (
    <div className="flex flex-col gap-3">
      <div>
        <FieldLabel>Water used (litres)</FieldLabel>
        <input type="number" min={0} value={litres} onChange={(e) => setLitres(Number(e.target.value))} className={inputClass} />
      </div>
      <PreviewButton onClick={() => onPreview(calcWater(litres))} />
    </div>
  );
}

function PreviewButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="mt-1 rounded-2xl bg-moss/10 text-moss font-medium py-3 border border-moss/30 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
    >
      <ScanLine size={15} />
      Calculate impact
    </button>
  );
}
