"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import BottomNav from "@/components/BottomNav";
import AchievementToast from "@/components/AchievementToast";
import { useAppStore } from "@/lib/store";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const hydrated = useAppStore((s) => s.hydrated);
  const profile = useAppStore((s) => s.profile);
  const darkMode = useAppStore((s) => s.darkMode);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  useEffect(() => {
    if (hydrated && !profile.authMethod) router.replace("/login");
  }, [hydrated, profile.authMethod, router]);

  if (!hydrated) return null;

  return (
    <div className="pb-28">
      <AchievementToast />
      {children}
      <BottomNav />
    </div>
  );
}
