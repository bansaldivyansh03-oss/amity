"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Heart, Zap, Sparkles, Droplet, PawPrint } from "lucide-react";
import { useAppStore, currentLevel } from "@/lib/store";
import { totalFor, carbonScore } from "@/lib/analytics";
import PageHeader from "@/components/PageHeader";
import type { PetSpecies } from "@/lib/types";

const PET_EMOJI: Record<PetSpecies, string> = {
  panda: "🐼",
  fox: "🦊",
  turtle: "🐢",
  owl: "🦉",
  red_panda: "🐾",
};

const PET_FACE: Record<PetSpecies, string[]> = {
  panda: ["🐼"],
  fox: ["🦊"],
  turtle: ["🐢"],
  owl: ["🦉"],
  red_panda: ["🐨"],
};

export default function ForestPage() {
  const activities = useAppStore((s) => s.activities);
  const gamification = useAppStore((s) => s.gamification);
  const pet = useAppStore((s) => s.pet);
  const setPetSpecies = useAppStore((s) => s.setPetSpecies);

  const today = new Date().toISOString().slice(0, 10);
  const score = carbonScore(totalFor(activities, today));
  const level = currentLevel(gamification.xp);
  const hour = new Date().getHours();
  const isNight = hour < 6 || hour >= 19;

  const treeCount = Math.min(9, 2 + level.idx * 1.2);
  const forestHealthy = score >= 50;

  const [interaction, setInteraction] = useState<string | null>(null);

  function playWithPet() {
    setInteraction("Playing fetch with sticks 🌿");
    setTimeout(() => setInteraction(null), 2000);
  }
  function feedPet() {
    setInteraction("Snack time! 🍃");
    setTimeout(() => setInteraction(null), 2000);
  }
  function cleanPet() {
    setInteraction("Splish splash 💧");
    setTimeout(() => setInteraction(null), 2000);
  }

  const skyGradient = isNight
    ? "linear-gradient(180deg, #0B1B16 0%, #142B22 60%, #1E3D30 100%)"
    : "linear-gradient(180deg, #BFE3D0 0%, #DCEEDA 55%, #F4F1E8 100%)";

  const trees = useMemo(
    () =>
      Array.from({ length: Math.round(treeCount) }).map((_, i) => ({
        x: 10 + i * (80 / Math.max(1, Math.round(treeCount) - 1)),
        scale: 0.7 + ((i * 37) % 40) / 100,
        delay: (i * 0.3) % 2,
      })),
    [treeCount]
  );

  return (
    <div className="pb-4">
      <PageHeader title="Virtual Forest" subtitle={`${Math.round(treeCount)} trees grown so far`} />

      <div className="px-5">
        {/* Scene */}
        <div
          className="relative w-full h-64 rounded-3xl overflow-hidden border border-border-soft"
          style={{ background: skyGradient }}
        >
          {/* Sun / moon */}
          <motion.div
            className="absolute rounded-full"
            style={{
              top: 18,
              right: 24,
              width: 34,
              height: 34,
              background: isNight ? "#EAF2EA" : "#F2C84B",
              boxShadow: isNight ? "0 0 18px rgba(234,242,234,0.5)" : "0 0 24px rgba(242,200,75,0.6)",
            }}
            animate={{ opacity: [0.85, 1, 0.85] }}
            transition={{ duration: 3, repeat: Infinity }}
          />

          {/* Stars */}
          {isNight &&
            Array.from({ length: 14 }).map((_, i) => (
              <div
                key={i}
                className="absolute rounded-full bg-mist pulse-soft"
                style={{
                  width: 2,
                  height: 2,
                  top: `${8 + ((i * 17) % 45)}%`,
                  left: `${(i * 23) % 92}%`,
                  animationDelay: `${i * 0.2}s`,
                }}
              />
            ))}

          {/* Drifting cloud / firefly layer */}
          {!isNight ? (
            <div className="absolute top-10 left-0 w-16 h-6 rounded-full bg-white/70 drift" style={{ animationDuration: "22s" }} />
          ) : (
            Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="absolute h-1 w-1 rounded-full bg-lichen pulse-soft"
                style={{ bottom: `${20 + ((i * 13) % 30)}%`, left: `${10 + ((i * 29) % 80)}%`, animationDelay: `${i * 0.4}s` }}
              />
            ))
          )}

          {/* Birds */}
          {!isNight && (
            <motion.div
              className="absolute text-lg"
              style={{ top: 30 }}
              animate={{ x: ["-10%", "110%"] }}
              transition={{ duration: 14, repeat: Infinity, ease: "linear" }}
            >
              🕊️
            </motion.div>
          )}

          {/* Ground */}
          <div className="absolute bottom-0 left-0 right-0 h-20" style={{ background: forestHealthy ? "var(--moss)" : "#8C7A4A", opacity: 0.9 }} />

          {/* Trees */}
          {trees.map((t, i) => (
            <motion.div
              key={i}
              className="absolute bottom-6 sway"
              style={{
                left: `${t.x}%`,
                transform: `scale(${t.scale})`,
                animationDelay: `${t.delay}s`,
                fontSize: 34,
                filter: forestHealthy ? "none" : "grayscale(40%) brightness(0.8)",
              }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08, duration: 0.5 }}
            >
              🌳
            </motion.div>
          ))}

          {/* Butterflies when healthy */}
          {forestHealthy &&
            Array.from({ length: 2 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-sm"
                style={{ bottom: 60 + i * 20 }}
                animate={{ x: [`${i * 30}%`, `${i * 30 + 40}%`, `${i * 30}%`] }}
                transition={{ duration: 8 + i * 2, repeat: Infinity, ease: "easeInOut" }}
              >
                🦋
              </motion.div>
            ))}

          {!forestHealthy && (
            <div className="absolute top-3 left-3 text-[11px] bg-black/30 text-mist px-2.5 py-1 rounded-full">
              Forest health is low — log some low-carbon activities today
            </div>
          )}
        </div>

        {/* Eco Pet */}
        <div className="mt-5 rounded-3xl bg-surface border border-border-soft p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-xs text-foreground-soft">Your Eco Pet</p>
              <p className="font-display text-lg font-semibold">{pet.name}</p>
            </div>
            <motion.div
              className="text-5xl"
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              {PET_FACE[pet.species][0]}
            </motion.div>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <Meter icon={Heart} label="Happiness" value={pet.happiness} color="var(--ember)" />
            <Meter icon={Zap} label="Energy" value={pet.energy} color="var(--sky)" />
            <Meter icon={Sparkles} label="Health" value={pet.health} color="var(--moss)" />
            <Meter icon={Droplet} label="Cleanliness" value={pet.cleanliness} color="var(--moss-light)" />
          </div>

          {interaction && (
            <p className="text-center text-sm text-moss font-medium mb-3 rise-fade">{interaction}</p>
          )}

          <div className="grid grid-cols-3 gap-2">
            <PetAction label="Play" onClick={playWithPet} />
            <PetAction label="Feed" onClick={feedPet} />
            <PetAction label="Clean" onClick={cleanPet} />
          </div>

          <div className="mt-4 flex items-center gap-2 overflow-x-auto scrollbar-none pt-1">
            <PawPrint size={14} className="text-foreground-soft shrink-0" />
            {(Object.keys(PET_EMOJI) as PetSpecies[]).map((species) => (
              <button
                key={species}
                onClick={() => setPetSpecies(species)}
                className={`h-9 w-9 rounded-full flex items-center justify-center shrink-0 border ${
                  pet.species === species ? "border-moss bg-moss/10" : "border-border-soft"
                }`}
              >
                {PET_FACE[species][0]}
              </button>
            ))}
          </div>
        </div>

        <p className="text-[11px] text-foreground-soft text-center mt-4 mb-2">
          Log low-carbon activities to grow your forest and keep {pet.name} happy.
        </p>
      </div>
    </div>
  );
}

function Meter({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Heart;
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-1">
        <Icon size={12} style={{ color }} />
        <span className="text-[11px] text-foreground-soft">{label}</span>
      </div>
      <div className="h-1.5 rounded-full bg-border-soft overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, backgroundColor: color }} />
      </div>
    </div>
  );
}

function PetAction({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="rounded-xl bg-moss/10 text-moss text-sm font-medium py-2.5 border border-moss/30 active:scale-95 transition-transform"
    >
      {label}
    </button>
  );
}
