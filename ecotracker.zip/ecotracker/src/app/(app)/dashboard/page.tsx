"use client";

import Link from "next/link";
import { useMemo } from "react";
import {
  Flame,
  Coins,
  TreeDeciduous,
  Droplets,
  Zap,
  Sparkles,
  Moon,
  Sun,
  ChevronRight,
} from "lucide-react";
import { AreaChart, Area, ResponsiveContainer, XAxis, Tooltip } from "recharts";
import { useAppStore, currentLevel } from "@/lib/store";
import {
  weeklySeries,
  totalFor,
  carbonScore,
  computeImpactStats,
  categoryBreakdown,
  last7Days,
} from "@/lib/analytics";
import { motivationalTip } from "@/lib/assistant";
import { getDailyChallenge } from "@/lib/achievements";
import GrowthRing from "@/components/GrowthRing";
import StatCard from "@/components/StatCard";
import { CATEGORY_ICON, CATEGORY_LABEL } from "@/components/categoryMeta";

export default function DashboardPage() {
  const profile = useAppStore((s) => s.profile);
  const activities = useAppStore((s) => s.activities);
  const gamification = useAppStore((s) => s.gamification);
  const pet = useAppStore((s) => s.pet);
  const darkMode = useAppStore((s) => s.darkMode);
  const toggleDarkMode = useAppStore((s) => s.toggleDarkMode);
  const completeDailyChallenge = useAppStore((s) => s.completeDailyChallenge);

  const today = new Date().toISOString().slice(0, 10);
  const todayKg = totalFor(activities, today);
  const score = carbonScore(todayKg);
  const week = useMemo(() => weeklySeries(activities), [activities]);
  const level = currentLevel(gamification.xp);
  const impact = useMemo(() => computeImpactStats(activities), [activities]);
  const topCategory = useMemo(() => categoryBreakdown(activities, last7Days()[0])[0], [activities]);
  const challenge = getDailyChallenge(gamification.dailyChallengeId ? gamification.dailyChallengeDate : today);
  const tip = motivationalTip(today + profile.name);

  return (
    <div className="px-5 pt-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-2xl bg-moss/15 flex items-center justify-center text-xl">
            {profile.avatar}
          </div>
          <div>
            <p className="text-xs text-foreground-soft">Welcome back</p>
            <p className="font-display text-lg font-semibold leading-tight">{profile.name || "Guest"}</p>
          </div>
        </div>
        <button
          onClick={toggleDarkMode}
          className="h-9 w-9 rounded-full bg-surface border border-border-soft flex items-center justify-center"
          aria-label="Toggle dark mode"
        >
          {darkMode ? <Sun size={16} /> : <Moon size={16} />}
        </button>
      </div>

      {/* Carbon score + level */}
      <div className="mt-6 rounded-3xl bg-surface border border-border-soft p-5 flex items-center gap-5">
        <GrowthRing score={score} size={128} />
        <div className="flex-1">
          <p className="text-xs text-foreground-soft">Today&apos;s emissions</p>
          <p className="font-mono text-2xl font-semibold">{todayKg.toFixed(1)} kg CO₂</p>
          <div className="mt-3">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="font-medium text-moss">{level.name}</span>
              <span className="text-foreground-soft">{level.next ? `→ ${level.next}` : "Max level"}</span>
            </div>
            <div className="h-1.5 rounded-full bg-border-soft overflow-hidden">
              <div
                className="h-full bg-moss rounded-full transition-all"
                style={{ width: `${level.progress}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Weekly graph */}
      <div className="mt-4 rounded-3xl bg-surface border border-border-soft p-4">
        <div className="flex items-center justify-between mb-1">
          <p className="text-sm font-medium">This week&apos;s CO₂</p>
          <Link href="/analytics" className="text-xs text-moss flex items-center gap-0.5">
            Details <ChevronRight size={12} />
          </Link>
        </div>
        <div className="h-28 -ml-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={week}>
              <defs>
                <linearGradient id="co2fill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--moss)" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="var(--moss)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="day"
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 10, fill: "var(--foreground-soft)" }}
              />
              <Tooltip
                contentStyle={{
                  background: "var(--surface)",
                  border: "1px solid var(--border-soft)",
                  borderRadius: 12,
                  fontSize: 12,
                }}
                formatter={(v) => [`${v} kg`, "CO₂"] as [string, string]}
              />
              <Area type="monotone" dataKey="co2" stroke="var(--moss)" strokeWidth={2} fill="url(#co2fill)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Gamification row */}
      <div className="grid grid-cols-3 gap-3 mt-4">
        <StatCard icon={Flame} label="Day streak" value={`${gamification.streak}`} accent="var(--ember)" />
        <StatCard icon={Coins} label="Green Coins" value={`${gamification.greenCoins}`} accent="#C99A3E" />
        <StatCard
          icon={Sparkles}
          label="XP"
          value={`${gamification.xp}`}
          sub={level.next ? `${level.progress}% to ${level.next}` : "Max"}
          accent="var(--sky)"
        />
      </div>

      {/* Daily challenge */}
      <div className="mt-4 rounded-3xl bg-canopy text-mist p-4 flex items-center gap-3">
        <div className="h-10 w-10 rounded-2xl bg-lichen/20 flex items-center justify-center shrink-0">
          <Sparkles size={18} className="text-lichen" />
        </div>
        <div className="flex-1">
          <p className="text-[11px] uppercase tracking-wide text-lichen">Daily challenge</p>
          <p className="text-sm font-medium leading-snug mt-0.5">{challenge.text}</p>
        </div>
        {gamification.dailyChallengeDone ? (
          <span className="text-xs text-lichen font-medium shrink-0">Done ✓</span>
        ) : (
          <button
            onClick={completeDailyChallenge}
            className="text-xs bg-lichen text-canopy font-semibold rounded-full px-3 py-1.5 shrink-0"
          >
            Mark done
          </button>
        )}
      </div>

      {/* Impact stats */}
      <div className="grid grid-cols-3 gap-3 mt-4">
        <StatCard
          icon={TreeDeciduous}
          label="Trees saved"
          value={`${impact.treesSavedEquivalent}`}
          sub="estimated"
          accent="var(--moss)"
        />
        <StatCard
          icon={Droplets}
          label="Water logged"
          value={`${impact.waterLoggedL}L`}
          accent="var(--sky)"
        />
        <StatCard
          icon={Zap}
          label="Energy logged"
          value={`${impact.energyLoggedKwh}kWh`}
          accent="var(--ember)"
        />
      </div>

      {/* Top category + tip */}
      {topCategory && (
        <div className="mt-4 rounded-3xl bg-surface border border-border-soft p-4 flex items-center gap-3">
          {(() => {
            const Icon = CATEGORY_ICON[topCategory.category];
            return (
              <div
                className="h-10 w-10 rounded-2xl flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${topCategory.color}22`, color: topCategory.color }}
              >
                <Icon size={18} />
              </div>
            );
          })()}
          <div>
            <p className="text-xs text-foreground-soft">Leading this week</p>
            <p className="text-sm font-medium">
              {CATEGORY_LABEL[topCategory.category]} · {topCategory.value}kg CO₂
            </p>
          </div>
        </div>
      )}

      <div className="mt-4 rounded-3xl border border-dashed border-moss/40 p-4">
        <p className="text-[11px] uppercase tracking-wide text-moss font-medium">AI tip of the day</p>
        <p className="text-sm mt-1 leading-relaxed">{tip}</p>
      </div>

      <div className="mt-4 mb-2 flex items-center justify-between rounded-3xl bg-surface border border-border-soft p-4">
        <div>
          <p className="text-xs text-foreground-soft">Your Eco Pet</p>
          <p className="text-sm font-medium">{pet.name} is {pet.happiness > 60 ? "thriving" : "waiting for you"}</p>
        </div>
        <Link href="/forest" className="text-xs text-moss flex items-center gap-0.5">
          Visit <ChevronRight size={12} />
        </Link>
      </div>
    </div>
  );
}
