"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Thermometer, Footprints, Sprout } from "lucide-react";
import { useAppStore } from "@/lib/store";

const SLIDES = [
  {
    icon: Thermometer,
    title: "The climate is changing, fast",
    body: "Global temperatures have risen about 1.2°C since pre-industrial times, driven mostly by carbon dioxide and methane from human activity — transport, energy, food, and waste.",
  },
  {
    icon: Footprints,
    title: "Your carbon footprint is personal",
    body: "Every trip, meal, and purchase carries an emissions cost. Seeing it broken down by category is the first step to knowing where your impact actually comes from.",
  },
  {
    icon: Sprout,
    title: "Small, tracked changes add up",
    body: "EcoTracker turns daily choices into a score, a growing virtual forest, and real progress — one logged activity at a time.",
  },
];

export default function OnboardingPage() {
  const [index, setIndex] = useState(0);
  const router = useRouter();
  const completeOnboarding = useAppStore((s) => s.completeOnboarding);

  const slide = SLIDES[index];
  const isLast = index === SLIDES.length - 1;

  function next() {
    if (isLast) {
      completeOnboarding();
      router.push("/login");
    } else {
      setIndex((i) => i + 1);
    }
  }

  return (
    <div className="min-h-dvh flex flex-col bg-background px-6 pt-16 pb-10">
      <div className="flex-1 flex flex-col items-center justify-center text-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.35 }}
            className="flex flex-col items-center"
          >
            <div className="h-20 w-20 rounded-[28px] bg-moss/15 flex items-center justify-center mb-8">
              <slide.icon size={34} className="text-moss" strokeWidth={1.6} />
            </div>
            <h2 className="font-display text-2xl font-semibold tracking-tight max-w-xs">
              {slide.title}
            </h2>
            <p className="text-foreground-soft mt-4 max-w-xs leading-relaxed">{slide.body}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex items-center justify-center gap-2 mb-8">
        {SLIDES.map((_, i) => (
          <button
            key={i}
            onClick={() => setIndex(i)}
            aria-label={`Go to slide ${i + 1}`}
            className={`h-1.5 rounded-full transition-all ${
              i === index ? "w-6 bg-moss" : "w-1.5 bg-border-soft"
            }`}
          />
        ))}
      </div>

      <div className="flex items-center gap-3">
        {!isLast && (
          <button
            onClick={() => {
              completeOnboarding();
              router.push("/login");
            }}
            className="text-sm text-foreground-soft px-4 py-3"
          >
            Skip
          </button>
        )}
        <button
          onClick={next}
          className="flex-1 rounded-2xl bg-moss text-mist font-medium py-3.5 active:scale-[0.98] transition-transform"
        >
          {isLast ? "Get started" : "Continue"}
        </button>
      </div>
    </div>
  );
}
